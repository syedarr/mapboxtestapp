package com.aapps.mapboxtestapplication;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.widget.Toast;


public class Splash extends AppCompatActivity implements ActivityCompat.OnRequestPermissionsResultCallback {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    boolean hasPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        hasPermission = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)

                == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)

                == PackageManager.PERMISSION_GRANTED;




        if (hasPermission)

        {

            new Handler().postDelayed(new Runnable() {

                /*
                 * Showing splash screen with a timer. This will be useful when you
                 * want to show case your app logo / company
                 */

                @Override
                public void run() {
                    // This method will be executed once the timer is over
                    // Start your app main activity

                        Intent i = new Intent(Splash.this, Navigation_Activity.class);
                        startActivity(i);

                        // close this activity
                        finish();



                }
            }, 2000);



        } else

        {

            //           Toast.makeText(this, "No Permission", Toast.LENGTH_LONG).show(); //show the permission request dialog.

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION,

                            android.Manifest.permission.ACCESS_FINE_LOCATION},

                    LOCATION_PERMISSION_REQUEST_CODE);

        }




    }

    @Override

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {

            case LOCATION_PERMISSION_REQUEST_CODE: {

                if (grantResults.length > 0

                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    new Handler().postDelayed(new Runnable() {

                        /*
                         * Showing splash screen with a timer. This will be useful when you
                         * want to show case your app logo / company
                         */

                        @Override
                        public void run() {
                            // This method will be executed once the timer is over
                            // Start your app main activity

                                Intent i = new Intent(Splash.this, Navigation_Activity.class);
                                startActivity(i);

                                // close this activity
                                finish();



                        }
                    }, 2000);

                    //Permission was granted. Do the Location related task.

                } else {

                    finish();
                    Toast.makeText(this, "Permission denied", Toast.LENGTH_LONG).show();

                    //permission denied, Disable the functionality that depends on this permission.

                }

            }

        }

    }


}